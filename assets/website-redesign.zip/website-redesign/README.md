# Website files

Upload this complete folder to the root of the GitHub repository, replacing the existing `index.html` and preserving its directory structure:

```text
index.html
research.html
contact.html
standard-map.html
infinite-fractals.html
styles.css
assets/
  scripts/
    standard-map.js
    mathjax-config.js
    infinite-fractals.js
  data/
    standard-map/
    infinite-fractals/
tools/
  generate_standard_map_data.py
  generate_multifractal_data.py
```

Keep the existing `pp_mh.jpg` and `CV.pdf` in that same root folder. The home-page learning buttons now lead to working, data-driven modules.

Both modules load generated data: changing a control redraws an already generated data slice rather than running an orbit calculation, variational minimisation, random sampling, or spectrum calculation in the visitor's browser. The standard-map module uses nine values of \(K\) from \(0\) to \(1\), and nine values of \(\varepsilon\) from \(0\) to \(0.1\); its map is \(y'=y+K\sin(2\pi x)+\varepsilon\sin(10\pi x)\). Its displayed \(\beta\)-curve is the closest sampled curve with a small positive discrete curvature, so numerical irregularities are not presented as mathematical features. The generation scripts are included for provenance and later refinement; they require only Python's standard library.

Equations use MathJax. Write inline mathematics as `\( ... \)` and displayed mathematics as `\[ ... \]`; the pages load MathJax from its CDN when viewed online.
